package deprecated;

import java.net.*;
import java.io.*;
import java.net.Socket;

public class SenderThread extends Thread {
    
    // declare low level and high level objects for input
    private InputStream inStream;
    private DataInputStream inDataStream;
    
    // declare low level and high level objects for output
    private OutputStream outStream;
    private DataOutputStream outDataStream;
    
    // declare socket
    private Socket connection;
    
    // connection Data
    private String remoteMachine;
    private int port;
    
    public SenderThread(String remoteMachine, int port) {
        
        this.remoteMachine = remoteMachine;
        this.port = port;
    }
    
    private void startSender() {
        try {
            System.out.println("altSend start");
            // attempt to create a connection to the server
            connection = new Socket(remoteMachine, port);
            System.out.println("altSend Socket");
            
            // create an input stream from the server
            inStream = connection.getInputStream();
            inDataStream = new DataInputStream(inStream);
            
            // create output stream to the server
            outStream = connection.getOutputStream();
            outDataStream = new DataOutputStream(outStream);
            System.out.println("altSend Streams");
            
            // send the host IP to the server
            outDataStream.writeUTF(connection.getLocalAddress().getHostAddress());
            
        } catch (UnknownHostException e) {
            System.out.println("Unknown host");
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        
        try {
            Thread.sleep(1000);
            send("String", "Nicklas rulz");
            Thread.sleep(1000);
            send("String", "Katzen > Hunde");
            Thread.sleep(1000);
            send("String", "Tau ist die besser Kreiskonstante!");
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    
    public void send(String typ, String text) {
        if ("String".equals(typ)) {
            try {
                System.out.println("sendet");
                outDataStream.writeUTF("\n" + text);
            } catch (IOException e) {
                System.out.println("Nachricht konnte nicht gesendet werden");
                // !!!! Ausgabe auf GUI
            }
            // try {
            // String success = inDataStream.readUTF();
            // System.out.println("SuccessAusgabe!!!: " + success);
            // if (!success.equals("successfull")) {
            // System.out.println("Nachricht konnte nicht gesendet werden dank javas schuld");
            // // !!!! Ausgabe auf GUI
            // } else {
            // System.out.println("Die Nachricht konnte  gesendet werden");
            // }
            // } catch (IOException e) {
            // System.out.println("Nachricht konnte nicht gesendet werden");
            // // !!!! Ausgabe auf GUI
            // e.printStackTrace();
            // }
        } else {
            System.out.println("Datentyp noch nicht unterstuetzt");
        }
    }
    
    public void run() {
        
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        startSender();
    }
}
