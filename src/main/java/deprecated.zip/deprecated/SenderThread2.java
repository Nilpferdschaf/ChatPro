package deprecated;

import io.net.events.StatusChangeEvent;
import io.net.listeners.StatusListener;

import java.net.*;
import java.io.*;
import java.net.Socket;

public class SenderThread2 extends Thread {
    
    private StatusListener sListener;
    // declare low level and high level objects for input
    private InputStream inStream;
    private DataInputStream inDataStream;
    
    // declare low level and high level objects for output
    private OutputStream outStream;
    private DataOutputStream outDataStream;
    
    // declare socket
    private Socket connection;
    
    // connection Data
    boolean connected = false;
    private String remoteMachine;
    private int port;
    
    public SenderThread2(String remoteMachine, int port) {
        this.remoteMachine = remoteMachine;
        this.port = port;
        startSender();
    }
    
    private void startSender() {
        try {
            System.out.println("neuSend start");
            // attempt to create a connection to the server
            connection = new Socket(remoteMachine, port);
            System.out.println("neuSend socket");
            connected = true;
            sListener.statusChanged(new StatusChangeEvent("Verbunden"));
            // create an input stream from the server
            inStream = connection.getInputStream();
            inDataStream = new DataInputStream(inStream);
            
            // create output stream to the server
            outStream = connection.getOutputStream();
            outDataStream = new DataOutputStream(outStream);
            
            // send the host IP to the server
            outDataStream.writeUTF(connection.getLocalAddress().getHostAddress());
            
        } catch (UnknownHostException e) {
            System.out.println("Unknow host");
            connected = false;
            sListener.statusChanged(new StatusChangeEvent("Getrennt"));
        } catch (IOException except) {
            System.out.println("Network Exception");
        }
    }
    
    public boolean send(String Typ, String Text) {
        if (connected) {
            if ("String".equals(Typ)) {
                try {
                    outDataStream.writeUTF(Text);
                } catch (IOException e) {
                    return false;
                }
                try {
                    String success = inDataStream.readUTF();
                    return !success.equals("successfull");
                } catch (IOException e) {
                    e.printStackTrace();
                    return false;
                }
            } else {
                System.out.println("Datentyp noch nicht unterstuetzt");
            }
        }
        return false;
    }
    
    void addStatusListener(StatusListener listener) {
        sListener = listener;
    }
    
    public void close() {
        connected = false;
        sListener.statusChanged(new StatusChangeEvent("Getrennt"));
        try {
            inStream.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        try {
            inDataStream.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        try {
            outStream.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        try {
            outDataStream.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        try {
            connection.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    
    public void run() {
        startSender();
    }
}
