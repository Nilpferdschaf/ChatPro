package deprecated;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class ChatKlasse {
    
    public static void main(String[] args) {
        
        // try {
        // String localHost = InetAddress.getLocalHost().getHostName();
        // for (InetAddress ia : InetAddress.getAllByName(localHost)) {
        // System.out.println(ia);
        // }
        // } catch (UnknownHostException e) {
        // // TODO Auto-generated catch block
        // e.printStackTrace();
        // }
        System.out.println("alt start");
        
        SenderThread sender;
        // sender = new SenderThread("25.163.206.71", 5004);
//         sender = new SenderThread("25.190.93.112", 5014);
         sender = new SenderThread("192.168.0.13", 5005);
//        sender = new SenderThread("192.168.0.11", 5001);
        
        // hier beim anderen port+1
        // sender = new SenderThread("25.4.78.219", 5001);
        // try {
        // sender = new
        // SenderThread(InetAddress.getByName("localhost").getHostAddress(),
        // 5002);
        //
        // sender.start();
        // } catch (UnknownHostException e) {
        // // TODO Auto-generated catch block
        // e.printStackTrace();
        // }
        
        sender.start();
        
        // hier beim anderen port-1
//        ReceiverThread receiver = new ReceiverThread(5001);
//        
//        receiver.start();
        
    }
}
